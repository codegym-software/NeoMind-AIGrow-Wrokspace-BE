package com.springboot.demo.service;

import com.springboot.demo.dto.project.*;

import java.util.List;

public interface ProjectService {
    ProjectDto create(String workspaceId, CreateProjectReq req, String currentUserId);
    List<ProjectDto> listInWorkspace(String workspaceId, boolean includeArchived, String keyword);
    ProjectDto rename(String projectId, String newName);
    void delete(String projectId); // soft-delete
    List<ProjectDto> listMine(String workspaceId, String currentUserId);
}
